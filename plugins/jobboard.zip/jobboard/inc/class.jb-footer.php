<?php
/**
 * JobBoard Footer.
 *
 * @class 		JobBoard_Page
 * @version		1.0.0
 * @package		JobBoard/Classes
 * @category	Class
 * @author 		FOX
 */

if (! defined('ABSPATH')) {
    exit();
}

if (! class_exists('JobBoard_Footer')) :
    class JobBoard_Footer{
        function __construct()
        {

        }
    }
endif;